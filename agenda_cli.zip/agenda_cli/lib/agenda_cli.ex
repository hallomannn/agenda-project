defmodule AgendaCli do
  alias AgendaCli.Store
  alias AgendaCli.Contacts

  def main do
    contacts = Store.load()
    loop(contacts)
  end

  
  def loop(contacts) do
    input = IO.gets("agenda> ")
    command = String.trim(input || "")

    case parse(command) do
      {:list} ->
        IO.inspect(contacts)
        loop(contacts)

      {:exit} ->
        IO.puts("Encerrando...")
        :ok

      {:add, contact} ->
        updated = Contacts.add(contacts, contact)
        Store.save(updated)
        IO.puts("Contato adicionado com sucesso!")
        loop(updated)

      {:show, id} ->
        contact = Contacts.find_by_id(contacts, id)

        if contact do
          IO.inspect(contact)
        else
          IO.puts("Contato não encontrado")
        end

        loop(contacts)

      {:del, id} ->
        updated = Contacts.delete(contacts, id)
        Store.save(updated)
        IO.puts("Contato removido com sucesso!")
        loop(updated)

      {:search, criteria} ->
        results = Contacts.search(contacts, criteria)
        IO.inspect(results)
        loop(contacts)

      {:edit, id, updates} ->
        updated = Contacts.edit(contacts, id, updates)
        Store.save(updated)
        IO.puts("Contato atualizado com sucesso!")
        loop(updated)

      :invalid ->
        IO.puts("Comando inválido")
        loop(contacts)
    end
  end

  
  def parse("list"), do: {:list}
  def parse("exit"), do: {:exit}
  def parse("add " <> args), do: {:add, parse_add(args)}
  def parse("show " <> id), do: {:show, String.to_integer(String.trim(id))}
  def parse("del " <> id), do: {:del, String.to_integer(String.trim(id))}
  def parse("search " <> args), do: {:search, parse_search(args)}
  def parse("edit " <> args), do: parse_edit(args)
  def parse(_), do: :invalid

  
  def parse_add(command) do
    %{
      id: System.system_time(:millisecond),
      name: extract_value(command, "--name"),
      company: extract_value(command, "--company"),
      phone: extract_value(command, "--phone"),
      email: extract_value(command, "--email"),
      metadata: "RXUgdXRpbGl6ZWkgSUEgbmVzc2UgdHJhYmFsaG8h"
    }
  end

  
  def parse_search(args) do
    cond do
      String.starts_with?(args, "--name ") ->
        {:name, String.replace_prefix(args, "--name ", "")}

      String.starts_with?(args, "--phone ") ->
        {:phone, String.replace_prefix(args, "--phone ", "")}

      String.starts_with?(args, "--email ") ->
        {:email, String.replace_prefix(args, "--email ", "")}
    end
  end

  
  def parse_edit(args) do
    [id_str | _] = String.split(args, " ")
    id = String.to_integer(id_str)

    updates = %{
      name: extract_value(args, "--name"),
      company: extract_value(args, "--company"),
      phone: extract_value(args, "--phone"),
      email: extract_value(args, "--email")
    }

    updates =
      Enum.reject(updates, fn {_key, value} ->
        value == ""
      end)
      |> Enum.into(%{})

    {:edit, id, updates}
  end

  
  def extract_value(command, flag) do
    case String.split(command, flag) do
      [_before, after_flag] ->
        after_flag
        |> String.trim()
        |> String.split(" --")
        |> hd()
        |> String.trim()

      _ ->
        ""
    end
  end
end