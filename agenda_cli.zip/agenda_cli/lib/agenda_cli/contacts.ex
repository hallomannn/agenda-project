defmodule AgendaCli.Contacts do
  def add(contacts, contact) do
    [contact | contacts]
  end

  def list(contacts) do
    contacts
  end

  def find_by_id(contacts, id) do
    Enum.find(contacts, fn contact ->
      contact.id == id
    end)
  end

  def delete(contacts, id) do
    Enum.reject(contacts, fn contact ->
      contact.id == id
    end)
  end

  def search(contacts, {field, value}) do
    value = String.downcase(value)

    Enum.filter(contacts, fn contact ->
      contact
      |> Map.get(field)
      |> String.downcase()
      |> String.contains?(value)
    end)
  end

  def edit(contacts, id, updates) do
    Enum.map(contacts, fn contact ->
      if contact.id == id do
        Map.merge(contact, updates)
      else
        contact
      end
    end)
  end
end